# AUTHOR ACTION REPORT — LSPV-Bench manuscript, final package (private, not for submission)

**Target journal:** Solar Energy (Elsevier, ISSN 0038-092X; official journal of ISES). Checked 11 Nov 2026: regular papers 4,000–6,000 words, highlights mandatory (3–5 bullets, ≤85 characters), numbered references, IF about 6.6 (JCR Q2), subscription route has no APC (open access optional, about US$3,300).
**Author:** A. Jaffar Sadiq Ali, sole and corresponding author.
**Evidence:** FULL_PAPER_RUN v2.0.4 (benchmark, reproduction gate 26/26) + FULL_PAPER_RUN v2.0.5 replication-only run (H4, SOFTWARE PASS, 378 min). No SMOKE or STANDARD numbers are used.
**Verdict: MINOR FIXES** — science, numbers and references are locked; three items below need the author before upload.

| # | Location | Severity | Issue / evidence | Exact fix |
|---|---|---|---|---|
| 1 | Data and code availability | Must do before upload (recommended) | The text says code, forecasts and tables "will be deposited in a public repository upon acceptance". Editor desk check point 8 prefers a specific statement. | Deposit notebook v2.0.5, configs, both results ZIPs on Zenodo/GitHub; replace the sentence with the DOI. |
| 2 | AI declaration vs Methods | Should do | The declaration states AI use for language, figure and equation formatting only, as instructed. Elsevier asks that AI used in the research process (for example writing analysis code) be described in Methods. The notebook was written with AI assistance. | Decide whether to add one Methods sentence, e.g. "The analysis notebook was written with the assistance of Claude (Anthropic) and checked by the author." I can add it on request. |
| 3 | Declarations | Confirm | Competing interests (none) and funding (none) are written as standard statements. | Confirm or edit. |
| 4 | Ref [29] | Confirm | Kaggle shows the dataset owner only as "anikannal"; listed as A. Kannal. | Confirm the name or cite as "anikannal". |
| 5 | Section 5.3 | Information | The base paper's own numbers are not quoted; the text describes its reported pattern (lower RMSE and smaller spread). | None needed. |
| 6 | Single-author voice | Information | Text keeps "we", which Elsevier accepts for single-author papers. | Change to "I" only if you prefer. |
| 7 | Colab | Housekeeping | The Drive notebook is now v2.0.5 with MODE = FULL_PAPER_RUN and REPLICATION_ONLY = True. | Set REPLICATION_ONLY = False before any benchmark rerun. |
| 8 | Project docs | Housekeeping | Older Project docs spell the base-paper author "Najaf"; the correct spelling is Najafi. | None in the manuscript. |

**Fixed in this round:** single author (title page, CRediT, declarations, cover letter); Table 1 rows checked against abstracts (4 corrected, Ge & Ji added, 3 rows without readable abstracts removed and described only at title level in the text); Table 2 makes, module types, ratings, tilt checked on DKASC pages; LightGBM search ranges and cell-temperature formula added (reproducibility); "We show X, unlike Y, because Z" sentence added; H4 replication added (Methods 3.8, Results 4.8, Table 9, Discussion 5.3, abstract, conclusion, highlight 5).

**Important replication nuance (reported in the paper):** the base-protocol 5.3% mean gain on Kaggle comes from one seed in which the unaugmented model stopped early (3,268 updates, RMSE 0.091); the median paired gain is 0.4% (Wilcoxon p = 0.85). The notebook's gate labels H4 "SUPPORTED" for Kaggle because it compares means; the manuscript states both the mean and the median.

**Editor desk check (8 points):** 1 scope fit ✔ (PV forecasting verification, cites Solar Energy papers); 2 contribution sentence ✔; 3 title/abstract problem→method→result→conclusion ✔; 4 gap stated ✔; 5 methods reproducible ✔ (ranges, formulas, splits, budgets, seeds); 6 figure captions self-contained ✔; 7 discussion explains why, limits, next steps ✔; 8 ethics/data statements ◐ (item 1).

**Phase 9 scan:** no colour, highlight, comments, tracked changes, hidden text or placeholders in any .docx; no em dashes; no forbidden phrases; 30 references, all cited, numbered by first appearance; every DOI resolved (Holm 1979 and LightGBM proceedings have none); abstract 239 words; main text about 4,800 words; 9 tables; 3 figures; rendered PDF inspected (22 pages).

**Review pass:** done by Claude Opus in this session. A separate Fable review was not possible from here (model switch is yours); if you want it, open the package in a Fable chat and ask for a reviewer-style read.
