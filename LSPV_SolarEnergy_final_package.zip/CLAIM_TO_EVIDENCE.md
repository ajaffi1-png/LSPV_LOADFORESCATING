# Claim-to-evidence table — LSPV-Bench manuscript

Source: FULL_PAPER_RUN v2.0.4 results ZIP (run FULL_PAPER_RUN-v2.0.4-fb6b2f5ea505-cf202de7d285). Replication (H4) source: FULL_PAPER_RUN v2.0.5 replication-only ZIP (run FULL_PAPER_RUN-v2.0.5-0e5d852b72fd-cf202de7d285-REPLICATION, SOFTWARE PASS). No SMOKE or STANDARD results are used in the manuscript.

| Location | Claim | Evidence | Status |
|---|---|---|---|
| Abstract, 4.1 | With 14 d, no LSTM option beat SP at 15 min | statistical_tests.csv vsSP lstm L14 h15: all ratios >1 (best transfer 1.060, CI 1.011–1.125) | MATCH |
| Abstract, 4.1 | LightGBM transfer skill 0.083 (0.064–0.097); physics 0.060 | vsSP lgbm L14 h15: 0.917 (0.903–0.936); 0.940 | MATCH (recomputed from forecasts) |
| Abstract, 4.2 | Transfer −10.3% (LSTM), −21.0% (LightGBM) at 14 d | H2 rows: 0.8975, 0.7898; Holm p <0.001 | MATCH (recomputed) |
| Abstract, 4.2 | DDPM vs replication −3.9% (LSTM), −1.6% (LightGBM) at 14 d | H1 rows: 0.9612 (Holm p 0.0018), 0.9837 (p 0.0125) | MATCH (recomputed) |
| Abstract, 4.2 | At 365 d DDPM equivalent to replication within ±2% | H1 L365 both backbones equivalent_2pct=True | MATCH |
| Abstract, 4.4 | LightGBM best option at 14 d ≠ 365 d on 3/3 arrays | research_gates.csv H3 lgbm 3 of 3 | MATCH |
| 4.2 | LSTM 60 d DDPM equivalent; LightGBM 60 d 0.964 p 0.002 | statistical_tests.csv H1 | MATCH |
| 4.2 | H2 at 60 d: 9.0% and 3.1% | H2 0.9104, 0.9695 | MATCH |
| 4.3, Table 7 | LSTM DDPM gain from July on T1 (0.944) and T3 (0.837) | main_results.csv seed-mean RMSE ratios | MATCH (recomputed; earlier review note had 0.946/0.858, superseded) |
| 4.5 | 19 of 30 interaction cells exclude 0 | interaction_backbone.csv / research_gates D2 | MATCH |
| 4.6 | 96% of DDPM values in range; SD 9% smaller; W1 0.031 | synthetic_validity.csv (90 runs) | MATCH |
| 4.6 | Augmentation amount: median −2.1% (−21.8% to +6.8%), exploratory | research_gates.csv sensitivity row | MATCH |
| 4.7, Table 8 | Per-task and one-off compute times | logs/cost_raw.csv | MATCH |
| 3.8 | 494 min, T4, versions | logs/run_manifest.json | MATCH |
| 3.8 | Reproduction gate 26/26 within ±2% | REPRO run (review doc claude/ddpm-lstm-pv-full-v204-review.md) | MATCH (from review; REPRO ZIP not in this workspace) |
| 3.1 | Standby rule flagged source 249 d Apr 2022–Jan 2023; no target days | data_audit/standby_days.csv | MATCH |
| 4.1 | SP RMSE 0.288 kW (5.6%) / 0.471 kW (9.2%), mean over arrays/origins | main_results.csv SP rows (mean of cell RMSE); pooled 15-min RMSE is 0.301 | MATCH (text says 'averaged over arrays and origins') |
| Abstract, 4.8, Table 9 | Base protocol reproduced 5.3% mean gain (Kaggle) | replication_base_paper.csv gain_base_protocol 0.0525 | MATCH (recomputed from per-seed table) |
| 4.8 | Gain rests on one seed (seed 1, B0 stopped at 3,268 updates, RMSE 0.091); median paired gain 0.4%, Wilcoxon p 0.85 | replication_per_seed.csv | MATCH (computed here) |
| 4.8 | Augmented model ~1.7× updates (12,461 vs 8,067) | replication_base_paper.csv updates_B0/B3 | MATCH |
| Abstract, 4.8 | Equal protocol: DDPM +0.8% RMSE (median 0.6%, p 0.43); jitter −0.3% | replication_base_paper.csv gain_equal −0.0084; per-seed table | MATCH |
| 4.8 | Yulara: −1.8% base, −1.0% equal, 3 seeds | replication_base_paper.csv | MATCH |
| 3.9 | Replication run 378 min, v2.0.5 | logs/run_manifest.json (replication ZIP) | MATCH |
