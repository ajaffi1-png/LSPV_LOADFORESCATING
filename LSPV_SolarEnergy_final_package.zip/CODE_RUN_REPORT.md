# CODE_RUN_REPORT — LSPV-Bench manuscript (11 Nov 2026)

What was executed here: (1) headline RMSE ratios recomputed from `predictions/forecasts_FULL_PAPER_RUN.npz` (seed-mean forecasts, daytime mask, kW errors) and compared with `tables/statistical_tests.csv`; (2) all manuscript tables regenerated from the FULL tables by `scripts/tables.py`; (3) Figs 1–3 regenerated from the FULL tables by `scripts/figs.py` and `scripts/fig1.py` (original notebook figures used per-cell mean skill; the manuscript figures use pooled ratios with 95% CIs to match the tests).

Not run here: the Colab notebook itself (FULL run stays in Colab, 494 min on T4); the reproduction rerun (done in Colab, 26/26 PASS).

| Check | Recomputed | Table | Status |
|---|---|---|---|
| vsSP A5_transfer lgbm 14 d, 15 min | 0.9174 | 0.9174 | MATCH |
| vsSP A4_physics lgbm 14 d, 15 min | 0.9398 | 0.9398 | MATCH |
| vsSP A5_transfer lstm 14 d, 15 min | 1.0597 | 1.0597 | MATCH |
| vsSP A0_target lstm 14 d, 15 min | 1.1808 | 1.1808 | MATCH |
| H1 A3_ddpm lstm 14 d, 15 min | 0.9612 | 0.9612 | MATCH |
| H1 A3_ddpm lgbm 14 d, 15 min | 0.9837 | 0.9837 | MATCH |
| H1 A3_ddpm lgbm 60 d, 15 min | 0.9642 | 0.9642 | MATCH |
| H2 A5_transfer lstm 14 d, 15 min | 0.8975 | 0.8975 | MATCH |
| H2 A5_transfer lgbm 14 d, 15 min | 0.7898 | 0.7898 | MATCH |
| H2 A5_transfer lstm 60 d, 15 min | 0.9104 | 0.9104 | MATCH |
| H2 A5_transfer lgbm 60 d, 15 min | 0.9695 | 0.9695 | MATCH |
| Metric self-test (RMSE, MAE, MBE, nRMSE, skill, DM, Holm) | — | metric_self_test.csv 9/9 | MATCH |
| Table 2 coverage, ratings | — | data_audit/array_selection.csv | MATCH |
| SP pooled RMSE, 15 min, L14 | 0.301 kW | manuscript reports mean of cell RMSEs 0.288 kW | MATCH after wording fix |

## Replication run (v2.0.5, replication-only, 11 Nov 2026)
| Check | Recomputed here | Table | Status |
|---|---|---|---|
| Kaggle gain, base protocol (pooled means) | 0.0525 | 0.0525 | MATCH |
| Kaggle gain, equal protocol | −0.0084 | −0.0084 | MATCH |
| Yulara gain, base / equal | −0.0184 / −0.0105 | same | MATCH |
| Kaggle per-seed median gain, Wilcoxon (base / equal) | +0.4%, p 0.85 / −0.6%, p 0.43 | not in run tables (computed from replication_per_seed.csv) | NEW, reported in 4.8 |
| Software gate | — | software_check.csv 7/7 PASS | MATCH |
