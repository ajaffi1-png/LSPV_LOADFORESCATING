# Reference verification table — LSPV-Bench manuscript (11 Nov 2026)

Rows 1–28 are the drafting order (the manuscript renumbers them by first citation); rows 29–30 keep their manuscript numbers. Every DOI was looked up on api.crossref.org (or arxiv.org for preprints) on 11 Nov 2026. Title, authors, year and volume/pages in the reference list are copied from the resolved record.

| # | Reference (short) | Identifier | Resolved? | Notes |
|---|---|---|---|---|
| 1 | Demir & Najafi 2026, Int. Trans. Electr. Energy Syst. | 10.1155/etep/6970304 | ✔ Crossref | Second author's surname is **Najafi** (earlier project notes wrote "Najaf"; corrected) |
| 2 | Antonanzas et al. 2016, Solar Energy 136:78–111 | 10.1016/j.solener.2016.06.069 | ✔ | |
| 3 | Yang et al. 2020, Solar Energy 210:20–37 | 10.1016/j.solener.2020.04.019 | ✔ | |
| 4 | Marquez & Coimbra 2013, J. Sol. Energy Eng. 135:011016 | 10.1115/1.4007496 | ✔ | |
| 5 | Iglesias et al. 2023, Neural Comput. Appl. 35:10123–10145 | 10.1007/s00521-023-08459-3 | ✔ | |
| 6 | Ho, Jain & Abbeel 2020, DDPM | arXiv:2006.11239 | ✔ arxiv.org | Cited as NeurIPS 33 (2020) proceedings |
| 7 | Wang et al. 2025, Energies 18:747 | 10.3390/en18030747 | ✔ | |
| 8 | Jin et al. 2026, Renew. Energy 259:124772 | 10.1016/j.renene.2025.124772 | ✔ Crossref search | Direct DOI lookup failed once; bibliographic search returned this DOI and title |
| 9 | Almaghrabi et al. 2025, Neural Comput. Appl. 37:26823–26843 | 10.1007/s00521-025-11645-0 | ✔ | |
| 10 | Bompai et al. 2026, IEEE CAI, 668–673 | 10.1109/CAI68641.2026.11536240 | ✔ | |
| 11 | Pan & Yang 2010, IEEE TKDE 22:1345–1359 | 10.1109/TKDE.2009.191 | ✔ | |
| 12 | Depoortere et al. 2025, Int. J. Forecast. 41:1223–1236 (SolNet) | 10.1016/j.ijforecast.2024.12.003 | ✔ | |
| 13 | Zhuo et al. 2025, Energy and AI 22:100616 (LFTL) | 10.1016/j.egyai.2025.100616 | ✔ | |
| 14 | Liao et al. 2024, Energy Convers. Manage. 322:119114 | 10.1016/j.enconman.2024.119114 | ✔ | |
| 15 | Ge & Ji 2026, Energies 19:1410 (CausalTransPV) | 10.3390/en19061410 | ✔ | |
| 16 | Quiles-Cucarella et al. 2026, IEEE Access 14:70996–71011 | 10.1109/ACCESS.2026.3691969 | ✔ | |
| 17 | Hochreiter & Schmidhuber 1997, Neural Comput. 9:1735–1780 | 10.1162/neco.1997.9.8.1735 | ✔ | |
| 18 | Ke et al. 2017, LightGBM, NeurIPS 30:3146–3154 | no DOI (proceedings) | ✔ known proceedings record | Standard citation |
| 19 | Grinsztajn, Oyallon & Varoquaux 2022 | arXiv:2207.08815 | ✔ arxiv.org | Cited as arXiv preprint |
| 20 | Anderson et al. 2023, JOSS 8:5994 (pvlib) | 10.21105/joss.05994 | ✔ | |
| 21 | Ineichen 2008, Solar Energy 82:758–762 | 10.1016/j.solener.2008.02.009 | ✔ | Candidate DOI 10.1016/j.solener.2007.12.003 resolved to an unrelated paper and was **rejected** |
| 22 | Erbs, Klein & Duffie 1982, Solar Energy 28:293–302 | 10.1016/0038-092X(82)90302-4 | ✔ | |
| 23 | Diebold & Mariano 1995, JBES 13:253–263 | 10.1080/07350015.1995.10524599 | ✔ | |
| 24 | Harvey, Leybourne & Newbold 1997, IJF 13:281–291 | 10.1016/S0169-2070(96)00719-4 | ✔ | |
| 25 | Holm 1979, Scand. J. Stat. 6:65–70 | no DOI (JSTOR 4615733) | ◐ standard record | Not machine-checked; classic reference |
| 26 | Künsch 1989, Ann. Stat. 17:1217–1241 | 10.1214/aos/1176347265 | ✔ | |
| 27 | Lakens 2017, Soc. Psychol. Personal. Sci. 8:355–362 | 10.1177/1948550617697177 | ✔ | |
| 28 | DKASC data portal | dkasolarcentre.com.au | ✔ page fetched | Page describes the data as open-access and free; no citation wording given |

| 29 | Kannal, Solar Power Generation Data (Kaggle) | kaggle.com/datasets/anikannal/solar-power-generation-data | ✔ page fetched | Owner shown only as username "anikannal"; author name A. Kannal to confirm |
| 30 | DKASC Yulara Desert Gardens array page | dkasolarcentre.com.au/source/yulara/yulara-1-fixed | ✔ page fetched | 1,058.4 kW poly-Si, installed March 2016 |

Not cited (could not verify a DOI in this session): Santos 2025, de Arruda 2025, Eeckt 2025, Qiao 2026, Wencheng 2024, Zhai 2025, Bashyal 2025 (DOIs listed only as "in CSV" in the synthesis matrix).
